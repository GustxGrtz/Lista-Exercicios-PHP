<?php

private $idFornecedor;
private $razaoSocial;
private $nomeFantasia;
private $cnpj;
private $responsavel;
private $email;
private $ddd;
private $telefone;

    public function fornecedor{


    public function fornecedores($idFornecedor, $razaoSocial, $nomeFantasia, $cnpj, $responsavel, $email, $ddd, $telefone) {

        $this -> $idFornecedor = $idFornecedor;
        $this -> $razaoSocial = $razaoSocial;
        $this -> $nomeFantasia = $nomeFantasia;
        $this -> $cnpj = $cnpj;
        $this -> $responsavel = $responsavel;
        $this -> $email = $email;
        $this -> $ddd = $email;
        $this -> $telefone = $telefone;


    }

    public function getId(){
        return $this -> idFornecedor;
    }
    
    public function setId(){
        return $this -> idFornecedor = idFornecedor;
    }

    public function getRazao(){
        return $this -> razaoSocial;
    }
    
    public function setRazao(){
        return $this -> razaoSocial = razaoSocial;
    }

    public function getFantasia(){
        return $this -> nomeFantasia;
    }
    
    public function setFantasia(){
        return $this -> nomeFantasia = nomeFantasia;
    }

    public function getCnpj(){
        return $this -> cnpj;
    }
    
    public function setCnpj(){
        return $this -> cnpj = cnpj;
    }

    public function getResponsavel(){
        return $this -> responsavel;
    }
    
    public function setResponsavel(){
        return $this -> responsavel = responsavel;
    }

    public function getEmail(){
        return $this -> email;
    }
    
    public function setEmail(){
        return $this -> email = email;
    }

    public function getDdd(){
        return $this -> ddd;
    }
    
    public function setDdd(){
        return $this -> ddd = ddd;
    }

    public function getTelefone(){
        return $this -> telefone;
    }
    
    public function setTelefone(){
        return $this -> telefone = telefone;
    }
}

?>