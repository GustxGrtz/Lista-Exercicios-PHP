<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Cadastro Fornecedor</title>
</head>
<body>

    <div class="cadastro">
    <h1>Cadastro De Fornecedor</h1>
    <div class="razao"></div>
    <h1>Razão Social: </h1>
    <input type="text" placeholder="Razão Social">
    <input type="submit">
    <br>
    <div class="fantasia"></div>
    <h1>Nome Fantasia: </h1>
    <input type="text" placeholder="Nome Fantasia">
    <input type="submit">
    <br>
    <div class="cnpj"></div>
    <h1>CNPJ: </h1>
    <input type="number" placeholder="CNPJ">
    <input type="submit">
    <br>
    <div class="responsavel"></div>
    <h1>Responsável: </h1>
    <input type="text" placeholder="Responsável">
    <input type="submit">
    <br>
    <div class="email"></div>
    <h1>E-Mail: </h1>
    <input type="e-mail" placeholder="E-Mail">
    <input type="submit">
    <br>
    <div class="DDD"></div>
    <h1>DDD: </h1>
    <input type="number" placeholder="DDD">
    <input type="submit">
    <br>
    <div class="telefone"></div>
    <h1>Telefone Celular: </h1>
    <input type="number" placeholder="Telefone Celular">
    <input type="submit">
    <br>
    </div>

    <!-- <input type="text" placeholder="Cadastrar">
    <input type="submit">
    <input type="text" placeholder="Ler">
    <input type="submit">
    <input type="text" placeholder="Atualizar">
    <input type="submit">
    <input type="text" placeholder="Deletar">
    <input type="submit">
 -->

<?php   

    // $conn conexao::Conectar();
    // $sql
    $stmt
    
?>

</body>
</html>