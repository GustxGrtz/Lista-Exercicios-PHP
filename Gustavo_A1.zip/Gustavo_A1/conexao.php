<?php
include_once("../php.php");

class conexao{

    public function Conectar() {

        // new mysql('$mysql80, $root, $positivo, $php');

        try {
            new PDO("mysql:host=localhost;dbname=php", 'root', 'positivo');
            return "Sucesso!";
        } catch (PDOException $e) {
            return "Erro ao conectar" $e -> getMessage();
        }

        // $conn conexao::Conectar();

        $sql = "INSERT INTO prova_final (razaoSocial, nomeFantasia, cnpj, responsavel, email, ddd, telefone) values (teste,teste,123,teste,aaa@gmail,041,3333333)";
        $stmt = $conn ->prepare($sql);

        $stmt->bind_param($razaoSocial, $nomeFantasia, $cnpj, $responsavel, $email, $ddd, $telefone);
    }
}

?>