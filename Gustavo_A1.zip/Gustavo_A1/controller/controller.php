<?php
include_once("../php.php");

    public function controller{
     

        public function controle($escolha) {
            
            switch ($opcao) {
                case 'criar':
                    $razaoSocial = $_POST('razaoSocial');
                    $nomeFantasia = $_POST('nomeFantasia');
                    $cpnj = $_POST('cnpj');
                    $responsavel = $_POST('responsavel');
                    $email = $_POST('email');
                    $ddd = $_POST('ddd');
                    $telefone = $_POST('telefone');
                    break;
                
                case 'ler':
                    $razaoSocial = $_GET('razaoSocial');
                    $nomeFantasia = $_GET('nomeFantasia');
                    $cpnj = $_GET('cnpj');
                    $responsavel = $_GET('responsavel');
                    $email = $_GET('email');
                    $ddd = $_GET('ddd');
                    $telefone = $_GET('telefone');
                    break;
                
                case 'atualizar':
                        $razaoSocial = $_UPDATE;
                        $nomeFantasia = $_UPDATE;
                        $cpnj = $_UPDATE;
                        $responsavel = $_UPDATE;
                        $email = $_UPDATE;
                        $ddd = $_UPDATE;
                        $telefone = $_UPDATE;
                        break;    
                
                 case 'deletar':
                    $razaoSocial = $_DELETE;
                    $nomeFantasia = $_DELETE;
                    $cpnj = $_DELETE;
                    $responsavel = $_DELETE;
                    $email = $_DELETE;
                    $ddd = $_DELETE;
                    $telefone = $_DELETE;
                    break;

                default:
                    echo "Ocorreu um erro";
                    break;
            }
        }
    }
?>
